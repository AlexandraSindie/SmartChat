package com.sindiealexandra.smartchat;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.squareup.picasso.Picasso;

public class ImageActivity extends AppCompatActivity {

    ImageView mImageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image);

        mImageView = findViewById(R.id.imageView);

        Intent intent = getIntent();
        String imageUri = intent.getStringExtra("IMAGE_URI");
        Picasso.get().load(imageUri).into(mImageView);
    }
}