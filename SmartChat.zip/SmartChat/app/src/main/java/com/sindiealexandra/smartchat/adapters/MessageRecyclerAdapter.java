package com.sindiealexandra.smartchat.adapters;

import android.annotation.SuppressLint;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.sindiealexandra.smartchat.R;
import com.sindiealexandra.smartchat.models.Message;
import com.sindiealexandra.smartchat.models.User;

import java.util.List;
import java.util.Objects;

public class MessageRecyclerAdapter extends RecyclerView.Adapter<MessageRecyclerAdapter.ViewHolder> {

    private FirebaseAuth mAuth;
    private FirebaseFirestore mFirestore;
    private FirebaseUser mCurrentUser;
    private TextView mContentTextView;
    private TextView mNameTextView;
    private List<Message> mMessages;
    private List<String> mMessageIDs;
    private User mReceiver;
    private static final String TAG = "Message Recycler Adapt";

    public MessageRecyclerAdapter(List<Message> messages, User receiver) {
        mMessages = messages;
        mReceiver = receiver;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.message_item, parent, false);
        return new ViewHolder(view);
    }

    // Fill card with data from Firestore
    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        // Fill cards with data
        String content = mMessages.get(position).getContent();
        mNameTextView.setText(mReceiver.getFirstName());
        mContentTextView.setText(content);
        if(Objects.equals(mMessages.get(position).getSender(), mCurrentUser.getUid())) {
            mNameTextView.setText(holder.itemView.getContext().getString(R.string.me));
            ConstraintSet set = new ConstraintSet();
            ConstraintLayout layout;

            layout = holder.itemView.findViewById(R.id.layout);
            set.clone(layout);
            set.clear(R.id.card, ConstraintSet.START);
            set.connect(R.id.card, ConstraintSet.RIGHT, 0, ConstraintSet.RIGHT, 10);
            set.applyTo(layout);
        }
    }

    @Override
    public int getItemCount() {
        return mMessages.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        public ViewHolder(@NonNull final View itemView) {
            super(itemView);

            mAuth = FirebaseAuth.getInstance();
            mFirestore = FirebaseFirestore.getInstance();
            mCurrentUser = mAuth.getCurrentUser();

            mContentTextView = itemView.findViewById(R.id.contentTextView);
            mNameTextView = itemView.findViewById(R.id.nameTextView);

        }
    }


    // Refresh fragment when something changes in the Recycler view
    public void updateMessages(List<Message> messages, List<String> messageIDs) {
        mMessages = messages;
        mMessageIDs = messageIDs;
        notifyItemChanged(mMessageIDs.size()-1);
    }
}
