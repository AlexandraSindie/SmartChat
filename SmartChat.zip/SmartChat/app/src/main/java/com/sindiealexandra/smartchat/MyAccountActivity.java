package com.sindiealexandra.smartchat;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.sindiealexandra.smartchat.models.User;
import com.squareup.picasso.Picasso;

import java.io.ByteArrayOutputStream;
import java.io.File;

public class MyAccountActivity extends AppCompatActivity {
    private FirebaseAuth mAuth;
    private FirebaseFirestore mFirestore;
    private FirebaseUser mCurrentUser;
    private StorageReference mStorageRef;

    private SharedPreferences mPreferences;

    private ProgressBar mProgressBar;
    private Toolbar mToolbar;
    private ImageView mImageView;
    private TextInputLayout mFirstNameTextInputLayout;
    private EditText mFirstNameEditText;
    private TextInputLayout mLastNameTextInputLayout;
    private EditText mLastNameEditText;
    private TextInputLayout mPhoneTextInputLayout;
    private EditText mPhoneEditText;
    private TextInputLayout mEmailTextInputLayout;
    private EditText mEmailEditText;
    private Button mSaveButton;
    private Button mDeleteButton;
    private Bitmap mImageBitmap;
    static final int REQUEST_IMAGE_CAPTURE = 1;
    private static final String TAG = "Account Activity";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_account);

        mAuth = FirebaseAuth.getInstance();
        mFirestore = FirebaseFirestore.getInstance();
        mCurrentUser = mAuth.getCurrentUser();
        mStorageRef = FirebaseStorage.getInstance().getReference();
        mPreferences = PreferenceManager.getDefaultSharedPreferences(this);

        // Configure Toolbar
        mToolbar = findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(getString(R.string.account_settings));
        }

        mProgressBar = findViewById(R.id.progressBar);
        mImageView = findViewById(R.id.imageView);
        mFirstNameTextInputLayout = findViewById(R.id.firstNameTextInputLayout);
        mFirstNameEditText = findViewById(R.id.firstNameEditText);
        mLastNameTextInputLayout = findViewById(R.id.lastNameTextInputLayout);
        mLastNameEditText = findViewById(R.id.lastNameEditText);
        mPhoneTextInputLayout = findViewById(R.id.phoneTextInputLayout);
        mPhoneEditText = findViewById(R.id.phoneEditText);
        mEmailTextInputLayout = findViewById(R.id.emailTextInputLayout);
        mEmailEditText = findViewById(R.id.emailEditText);
        mSaveButton = findViewById(R.id.saveButton);
        mDeleteButton = findViewById(R.id.deleteButton);

        fillForm();

        mImageView.setOnClickListener(view -> {
            Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
        });

        // When user clicks the Save button
        mSaveButton.setOnClickListener(view -> {
            // Get user input from form
            final String firstName = mFirstNameEditText.getText().toString().trim();
            final String lastName = mLastNameEditText.getText().toString().trim();
            final String phone = mPhoneEditText.getText().toString().trim();
            final String email = mEmailEditText.getText().toString().trim();

            // Clear errors
            mFirstNameTextInputLayout.setError(null);
            mLastNameTextInputLayout.setError(null);
            mPhoneTextInputLayout.setError(null);
            mEmailTextInputLayout.setError(null);

            // Check user input
            if (TextUtils.isEmpty(firstName)) {
                mFirstNameTextInputLayout.setError(getString(R.string.first_name_required_error));
                mFirstNameEditText.requestFocus();
            } else if (TextUtils.isEmpty(lastName)) {
                mLastNameTextInputLayout.setError(getString(R.string.last_name_required_error));
                mLastNameEditText.requestFocus();
            } else if (TextUtils.isEmpty(phone)) {
                mPhoneTextInputLayout.setError(getString(R.string.phone_required_error));
                mPhoneEditText.requestFocus();
            } else if (TextUtils.isEmpty(phone)) {
                mPhoneTextInputLayout.setError(getString(R.string.phone_required_error));
                mPhoneEditText.requestFocus();
            } else if (TextUtils.isEmpty(email)) {
                mEmailTextInputLayout.setError(getString(R.string.email_required_error));
                mEmailEditText.requestFocus();
            } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                mEmailTextInputLayout.setError(getString(R.string.email_format_error));
                mEmailEditText.requestFocus();
            } else {
                mProgressBar.setVisibility(View.VISIBLE);

                // Change user info in database
                modifyUser(firstName, lastName, phone, email);
                if(mImageBitmap != null) {
                    modifyImage(getImageUri(this, mImageBitmap).toString());
                }
            }
        });

        mDeleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DialogInterface.OnClickListener dialogClickListener = (dialog, option) -> {
                    switch (option) {
                        case DialogInterface.BUTTON_POSITIVE:
                            //Yes button clicked
                            deleteUser();
                            break;

                        case DialogInterface.BUTTON_NEGATIVE:
                            //No button clicked
                            break;
                    }
                };

                AlertDialog.Builder builder = new MaterialAlertDialogBuilder(MyAccountActivity.this);
                builder.setTitle(getString(R.string.delete_account_message_title));
                builder.setMessage(getString(R.string.delete_account_message)).setPositiveButton(getString(R.string.yes), dialogClickListener)
                        .setNegativeButton(getString(R.string.no), dialogClickListener).show();
            }
        });
    }

    // Inflate toolbar menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.my_account_menu, menu);
        return true;
    }

    // When the user clicks a button in the toolbar menu
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        Intent intent;
        switch (item.getItemId()) {
            // Go to MainActivity
            case R.id.mainPageButton:
                intent = new Intent(this, MainActivity.class);
                startActivity(intent);
                return true;
            // Log out user
            case R.id.logoutButton:
                mAuth.signOut();
                intent = new Intent(this, LoginActivity.class);
                startActivity(intent);
                finish();
                return true;
            default:
                return false;
        }
    }

    // Get user data and fill form
    public void fillForm() {
        // Get user info from database
        mCurrentUser = mAuth.getCurrentUser();
        mFirestore.collection("Users").document(mCurrentUser.getUid()).get().addOnSuccessListener(documentSnapshot -> {
            if (documentSnapshot != null) {
                mFirstNameEditText.setText(documentSnapshot.getString("firstName"));
                mLastNameEditText.setText(documentSnapshot.getString("lastName"));
                mPhoneEditText.setText(documentSnapshot.getString("phone"));
                // Get profile image if exists
                Picasso.get().load(documentSnapshot.getString("imageURI")).into(mImageView);
            }

            mProgressBar.setVisibility(View.INVISIBLE);
            mSaveButton.setEnabled(true);
        });

        // Get email from Authentication
        mEmailEditText.setText(mCurrentUser.getEmail());

    }

    // Update user in Authentication / Firestore
    public void modifyUser(final String firstName, final String lastName, final String phone, final String email) {
        // Create new user object
        User user = new User(firstName, lastName, phone);


        // Update user in the Users collection
        if (mCurrentUser != null) {
            mFirestore.collection("Users").document(mCurrentUser.getUid()).set(user)
                    .addOnSuccessListener(aVoid -> Log.d(TAG, "DocumentSnapshot successfully written!"))
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Log.w(TAG, "Error writing document", e);
                        }
                    });

            // Get email and password form shared preferences
            String userEmail = mPreferences.getString(getString(R.string.user_email), ""); // user actual email
            String password = mPreferences.getString(getString(R.string.user_password), "");

            AuthCredential credential = EmailAuthProvider.getCredential(userEmail, password);

            // Re-authenticate user
            mCurrentUser.reauthenticate(credential)
                    .addOnCompleteListener(task -> {
                        Log.d(TAG, "User re-authenticated.");
                        // Update email in Authentication
                        mCurrentUser.updateEmail(email)
                                .addOnCompleteListener(task1 -> {
                                    if (task1.isSuccessful()) {
                                        Log.d(TAG, "User email address updated.");
                                        // Update shared preferences
                                        mPreferences.edit().putString(getString(R.string.user_email), email).apply();
                                    } else {
                                        Log.w(TAG, "User email address not updated.");
                                        try {
                                            throw task1.getException();
                                        } catch (Exception e) {
                                            // Display a message to the user.
                                            Toast.makeText(getApplicationContext(), getString(R.string.update_failed),
                                                    Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                });
                    });
        }

        mProgressBar.setVisibility(View.INVISIBLE);

        // Start Main Activity
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(intent);
    }

    private void modifyImage(String imageURI) {
        mFirestore.collection("Users").document(mCurrentUser.getUid()).update("imageURI", imageURI)
                .addOnSuccessListener(aVoid -> {
                    Log.d(TAG, "DocumentSnapshot successfully updated!");
                    // Add images to Firebase Storage
                    File file = new File(getImageUri(this, mImageBitmap).getPath());
                    final StorageReference imageRef = mStorageRef.child("profile_images/" + file.getName());
                    UploadTask uploadTask = imageRef.putFile(getImageUri(this, mImageBitmap));

                    Task<Uri> urlTask = uploadTask.continueWithTask(task -> {
                        if (!task.isSuccessful()) {
                            throw task.getException();
                        }
                        // Continue with the task to get the download URL
                        return imageRef.getDownloadUrl();
                    }).addOnCompleteListener(new OnCompleteListener<Uri>() {
                        @Override
                        public void onComplete(@NonNull Task<Uri> task) {
                            if (task.isSuccessful()) {
                                Log.d(TAG, "Image successfully uploaded!");
                            }
                        }
                    });
                })
                .addOnFailureListener(e -> Log.w(TAG, "Error updating document", e));
    }

    // Delete user from Firestore / Authentication
    public void deleteUser() {
        // Delete user from Firestore
        mFirestore.collection("Users").document(mCurrentUser.getUid())
                .delete()
                .addOnSuccessListener(aVoid -> Log.d(TAG, "DocumentSnapshot successfully deleted!"))
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w(TAG, "Error deleting document", e);
                    }
                });

        // Delete user from Authentication
        mCurrentUser = mAuth.getCurrentUser();
        if(mCurrentUser != null) {
            mCurrentUser.delete()
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            Log.d(TAG, "User account deleted.");
                        }
                    });
        }

        // Clear shared preferences
        mPreferences.edit().putBoolean("checked", false).apply();
        mPreferences.edit().putString(getString(R.string.user_email), "").apply();
        mPreferences.edit().putString(getString(R.string.user_password), "").apply();

        // Start Main Activity
        Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
        startActivity(intent);
    }

    // After Take Image returns the location
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            mImageBitmap = (Bitmap) extras.get("data");
            mImageView.setImageBitmap(mImageBitmap);
        }
    }

    // BitmapToURI
    public Uri getImageUri(Context inContext, Bitmap inImage) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        String path = MediaStore.Images.Media.insertImage(inContext.getContentResolver(), inImage, "Title", null);
        return Uri.parse(path);
    }
}