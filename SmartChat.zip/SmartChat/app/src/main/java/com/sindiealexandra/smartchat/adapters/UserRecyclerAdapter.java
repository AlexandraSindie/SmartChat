package com.sindiealexandra.smartchat.adapters;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.sindiealexandra.smartchat.ChatActivity;
import com.sindiealexandra.smartchat.ImageActivity;
import com.sindiealexandra.smartchat.R;
import com.sindiealexandra.smartchat.models.User;
import com.squareup.picasso.Picasso;

import java.util.Date;
import java.util.List;

public class UserRecyclerAdapter extends RecyclerView.Adapter<UserRecyclerAdapter.ViewHolder> {

    private FirebaseAuth mAuth;
    private FirebaseFirestore mFirestore;
    private FirebaseUser mFirebaseUser;

    private TextView mNameTextView;
    private TextView mPhoneTextView;
    private TextView mRegisterDateTextView;

    private List<User> mUsers;
    private List<String> mUserIDs;
    private ImageView mImageView;

    private static final String TAG = "User Recycler Adapter";

    public UserRecyclerAdapter(List<User> users) {
        mUsers = users;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.users_item, parent, false);
        return new ViewHolder(view);
    }

    // Fill card with data from Firestore
    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        // Fill cards with data
        String firstName = mUsers.get(position).getFirstName();
        String lastName = mUsers.get(position).getLastName();
        mNameTextView.setText(String.format("%s %s", firstName, lastName));

        String phone = mUsers.get(position).getPhone();
        mPhoneTextView.setText(phone);

        long milliseconds = mUsers.get(position).getTimestamp().getTime();
        String date = DateFormat.format("MM/dd/yyyy", new Date(milliseconds)).toString();
        mRegisterDateTextView.setText(date);

        holder.itemView.setOnClickListener(view -> {
            Intent intent = new Intent(holder.itemView.getContext(), ChatActivity.class);
            intent.putExtra("USER_ID", mUserIDs.get(position));
            intent.putExtra("USER", mUsers.get(position));
            holder.itemView.getContext().startActivity(intent);
        });

        // Get profile image if exists
        if(mUsers.get(position).getImageURI() != null) {
            Picasso.get().load(mUsers.get(position).getImageURI()).into(mImageView);
        }

        mImageView.setOnClickListener(view -> {
            Intent intent = new Intent(holder.itemView.getContext(), ImageActivity.class);
            intent.putExtra("IMAGE_URI", mUsers.get(position).getImageURI());
            holder.itemView.getContext().startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return mUsers.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        public ViewHolder(@NonNull final View itemView) {
            super(itemView);

            mAuth = FirebaseAuth.getInstance();
            mFirestore = FirebaseFirestore.getInstance();
            mFirebaseUser = mAuth.getCurrentUser();

            mNameTextView = itemView.findViewById(R.id.nameTextView);
            mPhoneTextView = itemView.findViewById(R.id.phoneTextView);
            mRegisterDateTextView = itemView.findViewById(R.id.registerDateTextView);
            mImageView = itemView.findViewById(R.id.imageView);
        }
    }


    // Refresh fragment when something changes in the Recycler view
    public void updateUsers(List<User> users, List<String> userIDs) {
        mUsers = users;
        mUserIDs = userIDs;
        notifyDataSetChanged();
    }
}
