package com.sindiealexandra.smartchat;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.sindiealexandra.smartchat.adapters.MessageRecyclerAdapter;
import com.sindiealexandra.smartchat.models.Message;
import com.sindiealexandra.smartchat.models.User;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class ChatActivity extends AppCompatActivity {

    private Toolbar mToolbar;
    private FirebaseAuth mAuth;
    private FirebaseFirestore mFirestore;
    private FirebaseUser mCurrentUser;
    private Button mSendMessageButton;
    private ProgressBar mProgressBar;
    private TextInputLayout mSendMessageInputLayout;
    private EditText mSendMessageEditText;
    private String mReceiverID;
    private User mReceiver;
    private List<Message> mMessages;
    private RecyclerView mRecyclerView;
    private MessageRecyclerAdapter mMessageRecyclerAdapter;
    private List<String> mMessageIDs;


    private static final String TAG = "Chat Activity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        mToolbar = findViewById(R.id.toolbar);
        mAuth = FirebaseAuth.getInstance();
        mFirestore = FirebaseFirestore.getInstance();
        mCurrentUser = mAuth.getCurrentUser();
        mSendMessageButton = findViewById(R.id.sendMessageButton);
        mProgressBar = findViewById(R.id.progressBar);
        mSendMessageInputLayout = findViewById(R.id.sendMessageTextInputLayout);
        mSendMessageEditText = findViewById(R.id.sendMessageEditText);
        mMessages = new ArrayList<>();
        mMessageIDs = new ArrayList<>();

        Intent intent = getIntent();
        mReceiverID = intent.getStringExtra("USER_ID");
        mReceiver = (User) intent.getSerializableExtra("USER");

        mRecyclerView = findViewById(R.id.recyclerView);

        mRecyclerView.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getApplicationContext());
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        mMessageRecyclerAdapter = new MessageRecyclerAdapter(mMessages, mReceiver);
        mRecyclerView.setLayoutManager(linearLayoutManager);
        mRecyclerView.setAdapter(mMessageRecyclerAdapter);

        mProgressBar.setVisibility(View.VISIBLE);
        loadMessages();

        // Configure Toolbar
        setSupportActionBar(mToolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(String.format("%s %s", mReceiver.getFirstName(), mReceiver.getLastName()));
        }

        // When the user clicks the Send Message button
        mSendMessageButton.setOnClickListener(view -> {
            // Get user input from login form
            final String content = mSendMessageEditText.getText().toString().trim();

            // Clear errors
            mSendMessageInputLayout.setError(null);

            // Check user input
            if (TextUtils.isEmpty(content)) {
                mSendMessageInputLayout.setError(getString(R.string.message_required_error));
                mSendMessageEditText.requestFocus();
            } else {
                mProgressBar.setVisibility(View.VISIBLE);
                // Send message
                FirebaseUser firebaseUser = mAuth.getCurrentUser();
                Message message = new Message(content, mReceiverID, mAuth.getUid());
                if (firebaseUser != null) {
                    mFirestore.collection("Messages").document().set(message)
                            .addOnSuccessListener(aVoid -> {
                                Log.d(TAG, "DocumentSnapshot successfully written!");
                                loadMessages();
                            })
                            .addOnFailureListener(e -> Log.w(TAG, "Error writing document", e));
                }
                mProgressBar.setVisibility(View.INVISIBLE);
                mSendMessageEditText.setText("");
            }
        });
    }

    // Inflate toolbar menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    // When the user clicks a button in the toolbar menu
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        Intent intent;
        switch (item.getItemId()) {
            // Start the Account Activity
            case R.id.settingsButton:
                intent = new Intent(this, MyAccountActivity.class);
                startActivity(intent);
                return true;
            // Log out user
            case R.id.logoutButton:
                mAuth.signOut();
                intent = new Intent(this, LoginActivity.class);
                startActivity(intent);
                finish();
                return true;
            default:
                return false;
        }
    }

    // Load users from Firestore
    public void loadMessages() {
        mMessages.clear();
        mMessageIDs.clear();

        mFirestore.collection("Messages").orderBy("timestamp", Query.Direction.ASCENDING).get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                // Load users
                for (QueryDocumentSnapshot document : Objects.requireNonNull(task.getResult())) {
                    if (Objects.equals(document.getString("sender"), mCurrentUser.getUid()) && Objects.equals(document.getString("receiver"), mReceiverID)) {
                        mMessages.add(document.toObject(Message.class));
                        mMessageIDs.add(document.getId());
                    }
                    if (Objects.equals(document.getString("receiver"), mCurrentUser.getUid()) && Objects.equals(document.getString("sender"), mReceiverID)) {
                        mMessages.add(document.toObject(Message.class));
                        mMessageIDs.add(document.getId());
                    }
                }
                mMessageRecyclerAdapter.updateMessages(mMessages, mMessageIDs);
                mProgressBar.setVisibility(View.INVISIBLE);
                mRecyclerView.scrollToPosition(mMessageIDs.size() - 1);
            } else {
                Log.d(TAG, "Error getting documents: ", task.getException());
            }
        });
    }
}