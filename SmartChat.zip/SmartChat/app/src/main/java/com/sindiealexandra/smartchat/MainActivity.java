package com.sindiealexandra.smartchat;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.sindiealexandra.smartchat.adapters.UserRecyclerAdapter;
import com.sindiealexandra.smartchat.models.User;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {

    private Toolbar mToolbar;
    private FirebaseAuth mAuth;
    private FirebaseUser mCurrentUser;
    private FirebaseFirestore mFirestore;

    private ProgressBar mProgressBar;
    private RecyclerView mRecyclerView;
    private UserRecyclerAdapter mUserRecyclerAdapter;
    private List<User> mUsers;
    private List<String> mUserIDs;
    private static final String TAG = "Main Activity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mToolbar = findViewById(R.id.toolbar);
        mAuth = FirebaseAuth.getInstance();
        mCurrentUser = mAuth.getCurrentUser();
        mFirestore = FirebaseFirestore.getInstance();
        mUsers = new ArrayList<>();
        mUserIDs = new ArrayList<>();

        // Configure Toolbar
        setSupportActionBar(mToolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(getString(R.string.app_name));
        }

        mProgressBar = findViewById(R.id.progressBar);
        mRecyclerView = findViewById(R.id.recyclerView);

        mRecyclerView.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getApplicationContext());
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        mUserRecyclerAdapter = new UserRecyclerAdapter(mUsers);
        mRecyclerView.setLayoutManager(linearLayoutManager);
        mRecyclerView.setAdapter(mUserRecyclerAdapter);

        mProgressBar.setVisibility(View.VISIBLE);
        if (mCurrentUser != null) {
            loadUsers();
        }

    }

    // Check if user is signed in
    @Override
    protected void onStart() {
        super.onStart();
        if (mCurrentUser == null) {
            sendToLogin();
        }
    }

    // Start the Login Activity
    public void sendToLogin() {
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        finish();
    }

    // Inflate toolbar menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    // When the user clicks a button in the toolbar menu
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        Intent intent;
        switch (item.getItemId()) {
            // Start the Account Activity
            case R.id.settingsButton:
                intent = new Intent(this, MyAccountActivity.class);
                startActivity(intent);
                return true;
            // Log out user
            case R.id.logoutButton:
                mAuth.signOut();
                sendToLogin();
                return true;
            default:
                return false;
        }
    }

    // Load users from Firestore
    public void loadUsers() {
        mUsers = new ArrayList<>();
        mUserIDs = new ArrayList<>();

        mFirestore.collection("Users").get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                // Load users
                for (QueryDocumentSnapshot document : task.getResult()) {
                    if (!Objects.equals(document.getId(), mCurrentUser.getUid())) {
                        mUsers.add(document.toObject(User.class));
                        mUserIDs.add(document.getId());
                    }
                }
                mUserRecyclerAdapter.updateUsers(mUsers, mUserIDs);
                mProgressBar.setVisibility(View.INVISIBLE);
            } else {
                Log.d(TAG, "Error getting documents: ", task.getException());
            }
        });
    }

}